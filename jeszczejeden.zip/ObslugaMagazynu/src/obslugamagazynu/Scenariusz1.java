/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obslugamagazynu;

import obslugamagazynu.dane;


/**
 *
 * @author Dominika
 */
public class Scenariusz1 {
static int j;
static String[] tab = new String[1000];

public static void zapytanko(){
    j=0;
    for (int i=0; i<dane.chemiarozmiar; i++)
    {
     if(dane.chemia[i][0].contains(" ")) {
        tab[j]=dane.chemia[i][0];
        j++;	
      }}
    for (int i=0; i<dane.mięsorozmiar; i++)
    {
     if(dane.mięso[i][0].contains(" ")){
     tab[j]=dane.mięso[i][0];
     j++;
     }}
    for (int i=0; i<dane.owocerozmiar; i++)
    {
     if(dane.owoce[i][0].contains(" ")){
         tab[j]=dane.owoce[i][0];
         j++;
     }}
    for (int i=0; i<dane.warzywarozmiar; i++)
    {
     if(dane.warzywa[i][0].contains(" ")){
         tab[j]=dane.warzywa[i][0];
         j++;
     }}
    for (int i=0; i<dane.nabiałrozmiar; i++)
    {
     if(dane.nabiał[i][0].contains(" ")){
         tab[j]=dane.nabiał[i][0];
         j++;
     }}
    for (int i=0; i<dane.pieczyworozmiar; i++)
    {
     if(dane.pieczywo[i][0].contains(" ")){
         tab[j]=dane.pieczywo[i][0];
         j++;
     }}
}
}