package obslugamagazynu;

import java.awt.*;
import java.util.ArrayList;

public class koszyk {
    
    static String[][] koszyk;
    static int koszyk_rozm;
    static double l_kcal=0;
    static double l_białka = 0;
    static double l_tłuszczów = 0;
    static double l_węglowodanów = 0;
    static double cena;
    
    static void Create_Koszyk()
	{
            cena=0;
            koszyk_rozm = 0;
            koszyk = new String[150][6];
        }
    
    static public void Delete_Item(int item_index)
        //Usuwa przedmiot z koszyka. Jako parametr należy podać indeks w tablicy
        //koszyka przedmiotu, którego chcemy się pozbyć.
	{
            if(item_index<koszyk_rozm)
            {
                    l_kcal = l_kcal - Double.parseDouble(koszyk[item_index][1]);
                    l_białka = l_białka - Double.parseDouble(koszyk[item_index][2]);
                    l_tłuszczów = l_tłuszczów - Double.parseDouble(koszyk[item_index][3]);
                    l_węglowodanów = l_węglowodanów - Double.parseDouble(koszyk[item_index][4]);
                    cena = cena - Double.parseDouble(koszyk[item_index][5]);
                    
                for (int i=item_index; i<koszyk_rozm; i++)
                {
                    System.arraycopy(koszyk[i+1], 0, koszyk[i], 0, 6);

                    //2 sposób przekopiowania tablicy:
                    //for (int j=0; j<6; j++) { koszyk[i][j]=koszyk[i+1][j]; }
                }
                if (koszyk_rozm>0) koszyk_rozm = koszyk_rozm - 1;
            }
        }
    
    static public void Add_Item(String[][] items, int x)
        //Dodaje przedmiot do koszyka. Pierwszym parametem jest tablica,
        //w której przedmiot się znajduje. Drugim parametrem jest indeks przedmiotu.
        //Przykład: 
        //Koszyk.Add_Item(dane.nabiał, 1); (doda Bitą śmietanę do koszyka)
	{
            for (int i=0; i<6; i++) 
            {
                koszyk[koszyk_rozm][i] = items[x][i];
            }
            
            l_kcal = l_kcal + Double.parseDouble(koszyk[koszyk_rozm][1]);
            l_białka = l_białka + Double.parseDouble(koszyk[koszyk_rozm][2]);
            l_tłuszczów = l_tłuszczów + Double.parseDouble(koszyk[koszyk_rozm][3]);
            l_węglowodanów = l_węglowodanów + Double.parseDouble(koszyk[koszyk_rozm][4]);
            cena = cena + Double.parseDouble(koszyk[koszyk_rozm][5]);
            
            koszyk_rozm = koszyk_rozm + 1;
        }
    
    static void Show_Koszyk(Graphics g)
	{
            final int cons=150;
            g.drawString("﻿Nazwa",500+0*cons,490);
            g.drawString("wartość energetyczna[kcal]",500+1*cons/2,490);
            g.drawString("białko [g]",500+2*cons,490);
            g.drawString("tłuszcz [g]",500+3*cons,490);
            g.drawString("węglowodany [g]",500+4*cons,490);
            g.drawString("cena zł/kg",500+5*cons,490);
            for (int i=0; i<koszyk_rozm; i++)
            {
                for (int j=0; j<6; j++)
                {
                    g.drawString(koszyk[i][j] + " ",500+j*cons,500+i*10);
                }
            }
        }
    
    static void Podsumowanie_Koszyk(Graphics g)
	{   
            
            g.drawString("Kupiłeś " + koszyk_rozm + " produkt", applet.popx,applet.popy);
            if(koszyk_rozm==1) System.out.println(": ");
            else if(koszyk_rozm>1 && koszyk_rozm<5) System.out.println("y: ");
            else if(koszyk_rozm==0 || koszyk_rozm>4) System.out.println("ów: ");
            for (int i=0; i<koszyk_rozm; i++) System.out.println("- " + koszyk[i][0]);

            final int sp =15;
            g.drawString("*************************", applet.popx,applet.popy+1*sp);
            
            g.drawString("Suma kcal: " + (int) l_kcal + " kcal",applet.popx,applet.popy+2*sp);
            g.drawString("Suma białka: " + (int) l_białka + " g", applet.popx,applet.popy+3*sp);
            g.drawString("Suma tłuszczów: " + (int) l_tłuszczów + " g", applet.popx,applet.popy+4*sp);
            g.drawString("Suma węglowodanów: " + (int) l_węglowodanów + " g", applet.popx,applet.popy+5*sp);
            g.drawString("Do zapłaty: " + (int) cena + " zł", applet.popx,applet.popy+6*sp);
        }
    
    static int l_kcal_Currently()
    {
        return (int) l_kcal;
    }
    
    static int l_białka_Currently()
    {
        return (int) l_białka;
    }
    
    static int l_tłuszczów_Currently()
    {
        return (int) l_tłuszczów;
    }
    
    static int l_węglowodanów_Currently()
    {
        return (int) l_węglowodanów;
    }
    
    static int cena_Currently()
    {
        return (int) cena;
    }
}