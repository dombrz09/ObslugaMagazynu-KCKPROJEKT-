
package obslugamagazynu;

import java.util.ArrayList;
import java.awt.*;
import java.util.Date;
import java.util.Random;

public class musk {
    public static double poz=0;
    private static void nierozumiem(ArrayList<String> rozmowa)
    {
             if(rozmowa.size()>1)
                    {
                    rozmowa.add("Przykro mi ale nie zrozumiałem twoich intencji.");
                    }
    }
private static int STU (String[][] kosz, int rozm, String kwestia,  ArrayList<String> rozmowa)
    {
        int val = 0;
        for (int i=0; i<rozm;i++)
        {
            if(kwestia.contains(kosz[i][0]))
            {
                rozmowa.add("Usuwam "+kosz[i][0]);
                koszyk.Delete_Item(i);
                i=rozm;
                val =1;
            }
        }
        return val;
    }
    private static int ST (String[][] dział, int rozm, String kwestia, final double a, ArrayList<String> rozmowa,Graphics g)
    {
        int val = 0;
        for (int i=0; i<rozm;i++)
        {
            if(kwestia.contains(dział[i][0]))
            {
                if (i<rozm/4){
                    poz=a+0.1;
                }
                else if (i<rozm/2)
                {
                    poz=a+0.2;                    
                }
                else if (i<rozm*(3/4))
                {
                    poz=a+0.3;                    
                }
                else{
                    poz=a+0.4;
                }
                rozmowa.add("Ide po "+dział[i][0]);
                koszyk.Add_Item(dział,i);
                Obraz obraz = new Obraz(); 
                obraz.obraz(g,a,i,700,500,228,228);
                i=rozm;
                val =1;
            }
        }
        return val;
    }
    
    public static void analizuj (String temp, ArrayList<String> rozmowa, Graphics g)
    {
        poz=0;
        Random rand = new Random();
        Date date = new Date();
        rand.setSeed(date.getTime());
        int n = rand.nextInt(3);
                    if (rozmowa.size()==2 && (temp.contains("zień dobry") || temp.contains("hej") || temp.contains("Hej") ||temp.contains("zień Dobry")||temp.contains("itaj") || temp.contains("ześć") || temp.contains("iema")))
                        {
                            rozmowa.add("Zapytaj o dział lub podaj nazwe produktu by dodać go do koszyka");
                        }
                    else{
        if(temp.contains("usuń") || temp.contains("usun") || temp.contains("usuw") || temp.contains("Usuń") || temp.contains("Usun") || temp.contains("Usuw")){
            if(STU(koszyk.koszyk,koszyk.koszyk_rozm,temp,rozmowa)==1){}else{
                rozmowa.add("zrozumiałem żę coś mam usunać ale nia bardzo wiem co");
            }
        }else{
        if (temp.contains("chemi") || temp.contains("Chemi"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu chemia.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale chemia.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale chemia.---->");
                    break;
                default:
                    break;
            }
            for (int i=1; i<dane.chemiarozmiar; i++)
            {
                
                int temph = 490+(i%21)*10;
                int tempw;
                if(i>20)
                {
                    tempw = 750;
                }
                else
                {
                    tempw = 500;
                }

                g.drawString(dane.chemia[i][0], tempw, temph);
            }
        } else {

        if (temp.contains("nabiał") || temp.contains("Nabiał"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu nabiał.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale nabiał.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale nabiał.---->");
                    break;
                default:
                    break;
            }
                for (int i=1; i<dane.nabiałrozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.nabiał[i][0], tempw, temph);
                }
        } else {
        if (temp.contains("owoc") || temp.contains("Owoc"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu owoce.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale owoce.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale owoce.---->");
                    break;
                default:
                    break;
            }
                for (int i=1; i<dane.owocerozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                    g.drawString(dane.owoce[i][0], tempw, temph);
                }
        } else {
        if (temp.contains("pieczyw") || temp.contains("Pieczyw"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu pieczywo.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale pieczywo.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale pieczywo.---->");
                    break;
                default:
                    break;
            }    
            for (int i=1; i<dane.pieczyworozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.pieczywo[i][0], tempw, temph);
                }
        } else {
        if (temp.contains("warzyw") || temp.contains("Warzyw"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu warzywa.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale warzywa.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale warzywa.---->");
                    break;
                default:
                    break;
            }        
                for (int i=1; i<dane.warzywarozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.warzywa[i][0], tempw, temph);
                }
        } else {
        if (temp.contains("mięs") || temp.contains("Mięs"))
        {
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu mięso.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale mięso.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale mięso.---->");
                    break;
                default:
                    break;
            }        
                for (int i=1; i<dane.mięsorozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.mięso[i][0], tempw, temph);
                }
        }
        else
        if(ST(dane.chemia, dane.chemiarozmiar, temp, 3, rozmowa,g)==1){}else
        if(ST(dane.nabiał, dane.nabiałrozmiar, temp, 6, rozmowa,g)==1){}else
        if(ST(dane.owoce, dane.owocerozmiar, temp, 1, rozmowa,g)==1){}else
        if(ST(dane.warzywa, dane.warzywarozmiar, temp, 2, rozmowa,g)==1){}else
        if(ST(dane.mięso, dane.mięsorozmiar, temp, 4, rozmowa,g)==1){}else
        if(ST(dane.pieczywo, dane.pieczyworozmiar, temp, 5, rozmowa,g)==1){}else
        if(temp.contains("kosz") || temp.contains("Kosz") || temp.contains("koszyk") || temp.contains("Koszyk")){
           switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z koszyka.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w koszyku.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w koszyku.---->");
                    break;
                default:
                    break;
            }
            koszyk.Show_Koszyk(g);
        }else{
        if(temp.contains("podsum") || temp.contains("Podsum")){
           switch (n) {
                case 0:
                    rozmowa.add("Oto podsumówanie koszyka.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje podsumowanie koszyka.---->");
                    break;
                case 2:
                    rozmowa.add("Tak wygląda posumowanie koszyka.---->");
                    break;
                default:
                    break;
            }
            koszyk.Podsumowanie_Koszyk(g);
        }else{
            nierozumiem(rozmowa);
        }
        }
        }
        }
        }
        }
        }
        }
    }
    }
}