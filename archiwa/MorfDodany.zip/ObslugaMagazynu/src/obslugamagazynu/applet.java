package obslugamagazynu;

import java.applet.*;
import java.awt.*;
import java.util.ArrayList;




public class applet extends Applet {
    int iteracja=1;
   ArrayList<String> historia = new ArrayList<String>();
   public static final int popx=490; // początek okienka prawego współżenda x
   public static final int popy=500; // początek okienka prawego współżenda y
            dane Dane = new dane();
            Move move=new Move();         
            double y;
            TextField pole;
        public void init()
        {

            koszyk.Create_Koszyk();
            pole=new TextField(100);
            pole.setText("Witaj w naszym wirtualnym magazynie!!!"); // wiadomość początkowa, piersza linia
            add(pole);
            pole.setBounds(10,460,640,20);
            setLayout(null);
            dane.Create_Arrays();
            

        }
    
public void rysuj (Graphics g){
        
        Graphics2D g2=(Graphics2D) g;
        g2.setStroke(new BasicStroke(3));
        
        
       g.drawLine(10, 450, 1360, 450);
       g.drawLine(10, 450, 10, 10);             
       g.drawLine(10, 10, 1360, 10);
       g.drawLine(1360, 10, 1360, 450);
        
       g.setColor(Color.lightGray);
       g.fillRect(30, 369, 550, 70);
       g.fillRect(30, 219, 550, 70);
       g.fillRect(30, 69, 550, 70);
       g.fillRect(770, 369, 550, 70 );
       g.fillRect(770, 219, 550, 70);
       g.fillRect(770, 69, 550, 70);
        
       g.setColor(Color.black);
       g.drawRect(30, 369, 550, 70);
       g.drawRect(30, 219, 550, 70);
       g.drawRect(30, 69, 550, 70);
       g.drawRect(770, 369, 550, 70 );
       g.drawRect(770, 219, 550, 70);
       g.drawRect(770, 69, 550, 70);
       
       g.drawLine(610, 450, 610, 360);
       g.drawLine(610, 300, 610, 210);
       g.drawLine(610, 150, 610, 60);
       g.drawLine(740, 450, 740, 360);
       g.drawLine(740, 300, 740, 210);
       g.drawLine(740, 150, 740, 60);
       
       g.setColor(Color.MAGENTA);
       Font font = new Font ("SansSerif", Font.BOLD, 30 );
       g.setFont(font);
       g.drawString("Owoce", 260 , 410);
       g.drawString("Warzywa", 260, 260);
       g.drawString("Pieczywo", 260, 110);
       g.drawString("Nabiał", 1010, 110);
       g.drawString("Mięso", 1010, 260);
       g.drawString("Chemia", 1010, 410 );
        
        g.setColor(Color.white);
        g.drawLine(720, 450, 630, 450);      
}

 
    public void paint(Graphics g){     
        if(iteracja==1){
                        Obraz obraz = new Obraz();
            for(int i=1; i<=6; i++){
                int tym=0;
                switch (i){
                    case 1:
                        tym=dane.owocerozmiar-1;
                        break;
                    case 2:
                        tym=dane.warzywarozmiar-1;
                        break;
                    case 3:
                        tym=dane.chemiarozmiar-1;
                        break;
                    case 4:
                        tym=dane.mięsorozmiar-1;
                        break;
                    case 5:
                        tym=dane.pieczyworozmiar-1;
                        break;
                    case 6:
                        tym=dane.nabiałrozmiar-1;
                        break;
                }
                for(int j=1; j<=tym; j++){
                    obraz.obraz(g,i,j, 700,500,228,228);
                }
            }
        }
        rysuj(g);
        
        Font font2 = new Font ("SansSerif", Font.BOLD, 12 );
        g.setFont(font2);
        g.setColor(Color.black);
        
        
        String temp = pole.getText();
        historia.add(temp); 
        
        
        musk.analizuj(temp, historia, g); // TU SIE DZIEJE
        
                
        int r =(historia.size());       // wyświetlanie okienka dialogowego
        for(int i=r-1; i>=0; i=i)        
            {
               if(i%2==0)
               {
                   g.setColor(Color.red);
               }
               else
               {
                   g.setColor(Color.black);
               }
              g.drawString(historia.get(i), 10, 490+(r-i)*10);
              i--;
               pole.setText("");
            }
        g.setColor(Color.black); 
        
        
        y=musk.poz; // ruch
        if (y!=0)
        {
        move.sety(y);
        move.move(g);
        }
        else
        {
            if(move.polozenie==0)
            {
              g.setColor(Color.red);
              g.fillOval(675, 400, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 400, 30, 30);  
            }
            if(move.polozenie==1)
            {
              g.setColor(Color.red);
              g.fillOval(675, 320, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 320, 30, 30);                 
            }
            if(move.polozenie==2)
            {
              g.setColor(Color.red);
              g.fillOval(675, 160, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 160, 30, 30);                 
            }
        }
        iteracja++;
    }
     public boolean action(Event event, Object arg)
 {
  repaint();
  return true;
 }
    
}
