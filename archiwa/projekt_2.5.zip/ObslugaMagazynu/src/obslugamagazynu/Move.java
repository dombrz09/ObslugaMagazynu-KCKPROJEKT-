package obslugamagazynu;

import java.awt.Color;
import java.awt.Graphics;

public class Move {
    public void idzwlewo(int x, int y, Graphics g, int ile){
    int pom=x;
    for(int i=0; i<ile; i+=2){
        try{
            Thread.currentThread();
            Thread.sleep(18);
            int sz2=x;
            x= pom- i;
            g.clearRect(sz2-6, y-3, 40, 40);
            g.setColor(Color.red);
            g.fillOval(x, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(x, y, 30, 30);     
        }
            catch(Exception e){
                 e.printStackTrace();
            }
    }
    
}   
double y;
 public void sety(double wartosc){
     y=wartosc;
 }
public void idzwprawo(int x, int y, Graphics g, int ile){
        int pom=x;
    for(int i=0; i<ile; i+=2){
        try{
            Thread.currentThread();
            Thread.sleep(18);
            int sz2=x;
            x= pom+ i;
            g.clearRect(sz2-6, y-3, 40, 40);
            g.setColor(Color.red);
            g.fillOval(x, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(x, y, 30, 30);          
        }
            catch(Exception e){
                 e.printStackTrace();
            }
    }
}

public void idzdopolki(int x, int y, Graphics g, int ile){
    int pom=y;
    for(int i=0; i<ile; i+=2){
        try{
            Thread.currentThread();
            Thread.sleep(18);
            int w2=y;
            y= pom+ i;
            g.clearRect(x-3, y-4, 40, 31);
            g.setColor(Color.red);
            g.fillOval(x, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(x, y, 30, 30);        
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
}

public void idzodpolki (int x, int y, Graphics g, int ile){
    int pom=y;
    for(int i=0; i<ile; i+=2){
        try{
            Thread.currentThread();
            Thread.sleep(18);
            int w2=y;
            y= pom-i;
            g.clearRect(x-3, y+3, 39, 31);
            g.setColor(Color.red);
            g.fillOval(x, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(x, y, 30, 30);       
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
}

public void idzdogory(int y, Graphics g){
    int pom=y;
    for(int i=0; i<80; i+=2){
         try{
            Thread.currentThread();
            Thread.sleep(18);
            int y2=y;
            y= pom- i;
            g.clearRect(665, y2-6, 50, 50);
            g.setColor(Color.red);
            g.fillOval(675, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(675, y, 30, 30);        
        }
            catch(Exception e){
            e.printStackTrace();
            }
    }
    
}

public void idzwdol(int y, Graphics g){
    int pom=y;
    for(int i=0; i<80; i+=2){
         try{
            Thread.currentThread();
            Thread.sleep(18);
            int y2=y;
            y= pom+i;
            g.clearRect(665, y2-6, 50, 50);
            g.setColor(Color.red);
            g.fillOval(675, y, 30, 30);
            g.setColor(Color.black);
            g.drawOval(675, y, 30, 30);        
        }
            catch(Exception e){
            e.printStackTrace();
            }
    }
    
}

public boolean warunki1(Graphics g){
    
    polozenie=1;
    
            if(y==1.1){
                idzwlewo(675,320,g, 150);
                idzdopolki(525, 320, g, 10);
                idzodpolki(525, 330, g, 10);
                idzwprawo(525,320,g,150);
                return true;
            }
            else if(y==1.2){
                idzwlewo(675,320, g, 300);
                idzdopolki(375,320,g, 10);
                idzodpolki(375, 330, g, 10);
                idzwprawo(375, 320,g, 300);
                return true;   
            }
            else if(y==1.3){
                idzwlewo(675, 320, g, 450);
                idzdopolki(225, 320, g, 10);
                idzodpolki(225, 330, g,10);
                idzwprawo(225, 320, g, 450);
                return true;    
            }
            else if(y==1.4){
                idzwlewo(675, 320, g, 600);
                idzdopolki(75, 320, g, 10);
                idzodpolki(75, 330, g, 10);
                idzwprawo(75, 320, g, 600);
                return true;
            }
            else if(y==2.1){
                idzwlewo(675,320,g, 200);
                idzodpolki(475, 320, g, 20);
                idzdopolki(475, 300, g, 20);
                idzwprawo(475,320,g,200);
                return true;
            }
            else if(y==2.2){
                idzwlewo(675,320,g, 400);
                idzodpolki(275, 320, g, 20);
                idzdopolki(275, 300, g, 20);
                idzwprawo(275,320,g,400);
                return true; 
            }
            else if(y==3.1){
                idzwprawo(675,320,g,150);
                idzdopolki(825, 320, g, 10);
                idzodpolki(825, 330, g, 10);
                idzwlewo(825,320,g, 150);
                return true;
            }
            else if(y==3.2){
                idzwprawo(675,320,g,300);
                idzdopolki(975, 320, g, 10);
                idzodpolki(975, 330, g, 10);
                idzwlewo(975,320,g, 300);
                return true; 
            }
            else if(y==3.3){
                idzwprawo(675,320,g,450);
                idzdopolki(1125, 320, g, 10);
                idzodpolki(1125, 330, g, 10);
                idzwlewo(1125,320,g, 450);
                return true;   
            }
            else if(y==3.4){
                idzwprawo(675,320,g,600);
                idzdopolki(1275, 320, g, 10);
                idzodpolki(1275, 330, g, 10);
                idzwlewo(1275,320,g, 600);
                return true;  
            }
            else if(y==4.1){
                idzwprawo(675,320,g,200);
                idzodpolki(875, 320, g, 20);
                idzdopolki(875, 300, g, 20);
                idzwlewo(875,320,g, 200);
                return true;  
            }
            else if(y==4.2){
                idzwprawo(675,320,g,400);
                idzodpolki(1075, 320, g, 20);
                idzdopolki(1075, 300, g, 20);
                idzwlewo(1075,320,g, 400);
                return true;     
            }

            return false;
}

public boolean warunki2(Graphics g){
               
polozenie=2;
    
            if(y==5.1){
                idzwlewo(675,160,g, 150);
                idzodpolki(525, 160, g, 15);
                idzdopolki(525, 145, g, 15);
                idzwprawo(525,160,g,150);
                return true;
            }
            else if(y==5.2){
                idzwlewo(675,160, g, 300);
                idzodpolki(375, 160, g, 15);
                idzdopolki(375,145,g, 15);
                idzwprawo(375, 160,g, 300);
                return true;  
            }
            else if(y==5.3){
                idzwlewo(675, 160, g, 450);
                idzodpolki(225, 160, g,15);
                idzdopolki(225, 145, g, 15);
                idzwprawo(225, 160, g, 450);
                return true; 
            }
            else if(y==5.4){
                idzwlewo(675, 160, g, 600);
                idzodpolki(75, 160, g, 15);
                idzdopolki(75, 145, g, 15);
                idzwprawo(75, 160, g, 600);
                return true;
            }
            else if(y==2.3){
                idzwlewo(675,160,g, 200);
                idzdopolki(475, 160, g, 10);
                idzodpolki(475, 170, g, 10);
                idzwprawo(475,160,g,200);
                return true;
            }
            else if(y==2.4){
                idzwlewo(675,160,g, 400);
                idzdopolki(275, 160, g, 10);
                idzodpolki(275, 170, g, 10);
                idzwprawo(275,160,g,400);
                return true; 
            }
            else if(y==6.1){
                idzwprawo(675,160,g,150);
                idzodpolki(825, 160, g, 15);
                idzdopolki(825, 145, g, 15);
                idzwlewo(825,160,g, 150);
                return true;
            }
            else if(y==6.2){
                idzwprawo(675,160,g,300);
                idzodpolki(975, 160, g, 15);
                idzdopolki(975, 145, g, 15);
                idzwlewo(975,160,g, 300);
                return true; 
            }
            else if(y==6.3){
                idzwprawo(675,160,g,450);
                idzodpolki(1125, 160, g, 15);
                idzdopolki(1125, 145, g, 15);
                idzwlewo(1125,160,g, 450);
                return true;   
            }
            else if(y==6.4){
                idzwprawo(675,160,g,600);
                idzodpolki(1275, 160, g, 15);
                idzdopolki(1275, 145, g, 15);
                idzwlewo(1275,160,g, 600);
                return true; 
            }
            else if(y==4.3){
                idzwprawo(675,160,g,200);
                idzdopolki(875, 160, g, 20);
                idzodpolki(875, 180, g, 20);
                idzwlewo(875,160,g, 200);
                return true;  
            }
            else if(y==4.4){
                idzwprawo(675,160,g,400);
                idzdopolki(1075, 160, g, 20);
                idzodpolki(1075, 180, g, 20);
                idzwlewo(1075,160,g, 400);
                return true;  
            }
            return false;
}
       
double polozenie=0;
boolean ruch= true;

 public void move(Graphics g){
   
        if(polozenie==0){
            idzdogory(400, g);
            ruch=warunki1(g);
            if(ruch==false){
                warunki2(g);
            }
        }
        
        else if(polozenie==1){
            ruch=warunki1(g);
            if(ruch==false){
                idzdogory(320, g);   
                idzdogory(240,g);
                warunki2(g);
            } 
        }
        else if(polozenie==2){
            ruch=warunki2(g);
            if(ruch==false){
                idzwdol(160, g);
                idzwdol(240, g);
                warunki1(g);
            }
        }    
    }  
}
