package obslugamagazynu;

import java.applet.*;
import java.awt.*;
import java.util.ArrayList;




public class applet extends Applet {

   ArrayList<String> historia = new ArrayList<String>();
   
            dane Dane = new dane();
    TextField pole;
        public void init()
        {
            pole=new TextField(100);
            pole.setText("");
            add(pole);
            pole.setBounds(10,460,640,20);
            setLayout(null);
            dane.Create_Arrays();

        }
    
 
    public void paint(Graphics g){    //rysowanie magazynu 
        
        Graphics2D g2=(Graphics2D) g;
        g2.setStroke(new BasicStroke(3));
        
       g.drawLine(10, 450, 1360, 450);
       g.drawLine(10, 450, 10, 10);             
       g.drawLine(10, 10, 1360, 10);
       g.drawLine(1360, 10, 1360, 450);
        
       g.setColor(Color.LIGHT_GRAY);
       g.fillRect(30, 369, 550, 70);
       g.fillRect(30, 219, 550, 70);
       g.fillRect(30, 69, 550, 70);
       g.fillRect(770, 369, 550, 70 );
       g.fillRect(770, 219, 550, 70);
       g.fillRect(770, 69, 550, 70);
        
       g.setColor(Color.black);
       g.drawRect(30, 369, 550, 70);
       g.drawRect(30, 219, 550, 70);
       g.drawRect(30, 69, 550, 70);
       g.drawRect(770, 369, 550, 70 );
       g.drawRect(770, 219, 550, 70);
       g.drawRect(770, 69, 550, 70);
       
       g.drawLine(610, 450, 610, 360);
       g.drawLine(610, 300, 610, 210);
       g.drawLine(610, 150, 610, 60);
       g.drawLine(740, 450, 740, 360);
       g.drawLine(740, 300, 740, 210);
       g.drawLine(740, 150, 740, 60);
       
       g.setColor(Color.MAGENTA);
       Font font = new Font ("SansSerif", Font.BOLD, 30 );
       g.setFont(font);
       g.drawString("Owoce", 260 , 410);
       g.drawString("Warzywa", 260, 260);
       g.drawString("Pieczywo", 260, 110);
       g.drawString("Nabiał", 1010, 110);
       g.drawString("Mięso", 1010, 260);
       g.drawString("Chemia", 1010, 410 );
        
        g.setColor(Color.red);
        g.fillOval(675, 400, 30, 30);
        g.setColor(Color.black);
        g.drawOval(675, 400, 30, 30);
        
        g.setColor(Color.white);
        g.drawLine(720, 450, 630, 450);
        
        Font font2 = new Font ("SansSerif", Font.BOLD, 12 );
        g.setFont(font2);
        g.setColor(Color.black);
        String temp = pole.getText();
        historia.add(temp); 
        
        int r =(historia.size());
         
        for(int i=r-1; i>0; i=i)
        {
        g.drawString(historia.get(i), 10, 490+(r-i)*10);
        i--;
                    pole.setText("");
        }
        
        if (temp.contains("chemia"))
        {
                for (int i=1; i<dane.chemiarozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.chemia[i][0], tempw, temph);
                }
        }
        if (temp.contains("nabiał"))
        {
                for (int i=1; i<dane.nabiałrozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.nabiał[i][0], tempw, temph);
                }
        }
        if (temp.contains("owoce"))
        {
                for (int i=1; i<dane.owocerozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                    g.drawString(dane.owoce[i][0], tempw, temph);
                }
        }
        if (temp.contains("pieczywo"))
        {
                for (int i=1; i<dane.pieczyworozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.pieczywo[i][0], tempw, temph);
                }
        }
        if (temp.contains("warzywa"))
        {
                for (int i=1; i<dane.warzywarozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.warzywa[i][0], tempw, temph);
                }
        }
        if (temp.contains("mięso"))
        {
                for (int i=1; i<dane.mięsorozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.mięso[i][0], tempw, temph);
                }
        }
        
    }
     public boolean action(Event event, Object arg)
 {
  repaint();
  return true;
 }
    
}
