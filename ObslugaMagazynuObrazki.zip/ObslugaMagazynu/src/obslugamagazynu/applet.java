package obslugamagazynu;

import java.applet.*;
import java.awt.*;
import java.util.ArrayList;




public class applet extends Applet {

   ArrayList<String> historia = new ArrayList<String>();
   
   
   dane Dane = new dane();
   Obraz show=new Obraz();         
   Move move=new Move();         
            double y;
    TextField pole;
        public void init()
        {
            pole=new TextField(100);
            pole.setText("Witaj w naszym wirtualnym magazynie!!!"); // wiadomość początkowa, piersza linia
            add(pole);
            pole.setBounds(10,460,640,20);
            setLayout(null);
            dane.Create_Arrays();

        }
    
public void rysuj (Graphics g){
        
        Graphics2D g2=(Graphics2D) g;
        g2.setStroke(new BasicStroke(3));
        
        
       g.drawLine(10, 450, 1360, 450);
       g.drawLine(10, 450, 10, 10);             
       g.drawLine(10, 10, 1360, 10);
       g.drawLine(1360, 10, 1360, 450);
        
       g.setColor(Color.lightGray);
       g.fillRect(30, 369, 550, 70);
       g.fillRect(30, 219, 550, 70);
       g.fillRect(30, 69, 550, 70);
       g.fillRect(770, 369, 550, 70 );
       g.fillRect(770, 219, 550, 70);
       g.fillRect(770, 69, 550, 70);
        
       g.setColor(Color.black);
       g.drawRect(30, 369, 550, 70);
       g.drawRect(30, 219, 550, 70);
       g.drawRect(30, 69, 550, 70);
       g.drawRect(770, 369, 550, 70 );
       g.drawRect(770, 219, 550, 70);
       g.drawRect(770, 69, 550, 70);
       
       g.drawLine(610, 450, 610, 360);
       g.drawLine(610, 300, 610, 210);
       g.drawLine(610, 150, 610, 60);
       g.drawLine(740, 450, 740, 360);
       g.drawLine(740, 300, 740, 210);
       g.drawLine(740, 150, 740, 60);
       
       g.setColor(Color.MAGENTA);
       Font font = new Font ("SansSerif", Font.BOLD, 30 );
       g.setFont(font);
       g.drawString("Owoce", 260 , 410);
       g.drawString("Warzywa", 260, 260);
       g.drawString("Pieczywo", 260, 110);
       g.drawString("Nabiał", 1010, 110);
       g.drawString("Mięso", 1010, 260);
       g.drawString("Chemia", 1010, 410 );
        
        g.setColor(Color.white);
        g.drawLine(720, 450, 630, 450);      
}

 
    public void paint(Graphics g){    //rysowanie magazynu 
        

        rysuj(g);
        Font font2 = new Font ("SansSerif", Font.BOLD, 12 );
        g.setFont(font2);
        g.setColor(Color.black);
        
        
        String temp = pole.getText();
        historia.add(temp); 
        
       
        musk.analizuj(temp, historia, g); // TU SIE DZIEJE
        
              
        int r =(historia.size());       // wyświetlanie okienka dialogowego
        for(int i=r-1; i>=0; i=i)        
            {
               if(i%2==0)
               {
                   g.setColor(Color.red);
               }
               else
               {
                   g.setColor(Color.black);
               }
              g.drawString(historia.get(i), 10, 490+(r-i)*10);
              i--;
               pole.setText("");
            }
        
        
        g.setColor(Color.black); 
        y=musk.poz; // ruch
        show.obraz(g, musk.szafka, musk.pozycja);
        if (y!=0)
        {
        move.sety(y);
        move.move(g);
        }
        
        else
        {
            if(move.polozenie==0)
            {
              g.setColor(Color.red);
              g.fillOval(675, 400, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 400, 30, 30);  
            }
            if(move.polozenie==1)
            {
              g.setColor(Color.red);
              g.fillOval(675, 320, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 320, 30, 30);                 
            }
            if(move.polozenie==2)
            {
              g.setColor(Color.red);
              g.fillOval(675, 160, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 160, 30, 30);                 
            }
        }
        
         
   
        
    }
     public boolean action(Event event, Object arg)
 {   
  repaint();
  return true;
 }   
}
