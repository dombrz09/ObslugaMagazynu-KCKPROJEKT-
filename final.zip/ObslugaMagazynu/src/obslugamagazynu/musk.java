
package obslugamagazynu;

import java.util.ArrayList;
import java.awt.*;
import java.util.Date;
import java.util.Random;
import static morfologik.stemming.polish.PolishMorfologikStemmerTest.stem;
import morfologik.stemming.polish.PolishStemmer;

public class musk {
    public static double poz=0;
    public static int czyza=0;  
    public static int ilość=1;
    private static void nierozumiem(ArrayList<String> rozmowa)
    {
             if(rozmowa.size()>1)
                    {
                    rozmowa.add("Przykro mi ale nie zrozumiałem twoich intencji.");
                    }
    }
    private static int szukanie100000(String tempo, ArrayList<String> rozmowa,Graphics g, boolean zaprzeczenie, boolean ToNieJestPierwszaAkcja, Move move){
        if(ST(dane.chemia, dane.chemiarozmiar, tempo, 3, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.nabiał, dane.nabiałrozmiar, tempo, 6, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.owoce, dane.owocerozmiar, tempo, 1, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.warzywa, dane.warzywarozmiar, tempo, 2, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.mięso, dane.mięsorozmiar, tempo, 4, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.pieczywo, dane.pieczyworozmiar, tempo, 5, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        return 0;
        return 1;
    }
    private static int ST (String[][] dział, int rozm, String kwestia, final double a, ArrayList<String> rozmowa,Graphics g, boolean zaprzeczenie, boolean nAkcji, Move move)
    {
        int val = 0;
        for (int i=0; i<rozm;i++)
        {
            if(kwestia.contains(dział[i][0]))
            {
                if(zaprzeczenie==false)
                {
                if (i<rozm/4){
                    poz=a+0.1;
                }
                else if (i<rozm/2)
                {
                    poz=a+0.2;                    
                }
                else if (i<rozm*(3/4))
                {
                    poz=a+0.3;                    
                }
                else{
                    poz=a+0.4;
                }
                if(nAkcji==true){rozmowa.add(" ");}
                String string = new String();
                string="Ide po "+dział[i][0];
                if(ilość!=1){string=string+" razy "+ilość;}
                rozmowa.add(string);
                for(int j=0; j<ilość; j++)
                {
                koszyk.Add_Item(dział,i);
                }
                ilość=1;
                Obraz obraz = new Obraz(); 
                obraz.obraz(g,a,i,700,500,228,228);
        g.clearRect(0, 490, 300, 500);
        int r =(rozmowa.size());       // wyświetlanie okienka dialogowego
        for(int j=r-1; j>=0; j=j)        
            {
               if(j%2==0)
               {
                   g.setColor(Color.red);
               }
               else
               {
                   g.setColor(Color.black);
               }
              g.drawString(rozmowa.get(j), 10, 490+(r-j)*10);
              j--;
            }
        g.setColor(Color.black);                
                
        applet.y=musk.poz; // ruch
        if (applet.y!=0)
        {
        move.sety(applet.y);
        move.move(g);
        }
        else
        {
            if(move.polozenie==0)
            {
              g.setColor(Color.red);
              g.fillOval(675, 400, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 400, 30, 30);  
            }
            if(move.polozenie==1)
            {
              g.setColor(Color.red);
              g.fillOval(675, 320, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 320, 30, 30);                 
            }
            if(move.polozenie==2)
            {
              g.setColor(Color.red);
              g.fillOval(675, 160, 30, 30);
              g.setColor(Color.black);
              g.drawOval(675, 160, 30, 30);                 
            }
        }

        
                i=rozm;
                val =1;
                nAkcji=true;
                }
                else{zaprzeczenie=false; ilość=1;}
            }
        }
        return val;
    }
    private static String[] Morf(String kwestia)
    {
        kwestia=kwestia+" ";
        if(kwestia.contains(",")){
            String re = new String();
            String[] temp = kwestia.split(",");
            for(String i: temp)
            {
                re=re+i+" , ";
            }
            kwestia=re.substring(0,re.length()-2);
        }
        if(kwestia.contains("!")){
            String re = new String();
            String[] temp = kwestia.split("!");
            for(String i: temp)
            {
                re=re+i+" ! ";                         
            }
            kwestia=re.substring(0,re.length()-2);

        }
         if(kwestia.contains("?")){
            String re = new String();
            String[] temp = kwestia.split("\\?");
            for(String i: temp)
            {
                re=re+i+" \\? ";
            }
            kwestia=re.substring(0,re.length()-2);
        }
         if(kwestia.contains(".")){
            String re = new String();
            String[] temp = kwestia.split("\\.");
            for(String i: temp)
            {
                re=re+i+" \\. ";
            }
            kwestia=re.substring(0,re.length()-2);
        }
        while(kwestia.contains("  ")){
            String re = new String();
            String[] temp = kwestia.split("  ");
            for(String i: temp)
            {
                re=re+i+" ";                         
            }
            kwestia=re.substring(0,re.length()-1);
        }
                
        String[] temp = new String[100];
        PolishStemmer s = new PolishStemmer();
        int prev =0;
        int index =0;
        
            if(kwestia.contains(" ")){
                prev=kwestia.indexOf(" ");
            }
            else
            {
                prev=kwestia.length();
            }
        while(prev>0)
        {
            try{
                if (stem(s,kwestia.substring(0, prev))[0].equals("chusteczka"))
                    temp[index] = "chusteczki";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("kroić"))
                    temp[index] = "krojony";
               
                else if (stem(s,kwestia.substring(0, prev))[0].equals("żeberko"))
                    temp[index] = "żeberka";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("kisić"))
                    temp[index] = "kiszona";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("pekiński"))
                    temp[index] = "pekińska";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("lodowy"))
                    temp[index] = "lodowa";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("włoski"))
                    temp[index] = "włoska";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("szparagowy"))
                    temp[index] = "szparagowa";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("zielony"))
                    temp[index] = "zielona";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("żółty"))
                    temp[index] = "żółta";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("fiński"))
                    temp[index] = "fińska";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("wiejski"))
                    temp[index] = "wiejska";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("słonecznik"))
                    temp[index] = "słonecznikiem";

                else if (stem(s,kwestia.substring(0, prev))[0].equals("szary"))
                    temp[index] = "szara";

                else if (stem(s,kwestia.substring(0, prev))[0].equals("topić"))
                    temp[index] = "topiony";
                                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("kanapka"))
                    temp[index] = "kanapek";

                else if (stem(s,kwestia.substring(0, prev))[0].equals("czekoladowy"))
                    temp[index] = "czekoladowe";

                else if (stem(s,kwestia.substring(0, prev))[0].equals("malinowy"))
                    temp[index] = "malinowe";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("udko"))
                    temp[index] = "udka";                

                else if (stem(s,kwestia.substring(0, prev))[0].equals("jajko"))
                    temp[index] = "jajka";

                else if (stem(s,kwestia.substring(0, prev))[0].equals("skrzydełko"))
                    temp[index] = "skrzydełka";                
       
                else if (stem(s,kwestia.substring(0, prev))[0].equals("malina"))
                    temp[index] = "maliny";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("budyń"))
                    temp[index] = "budyniem";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("dżem"))
                    temp[index] = "dżemem";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("kruszonka"))
                    temp[index] = "kruszonką";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("zwykły"))
                    temp[index] = "zwykła";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("mak"))
                    temp[index] = "makiem";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("drobiowy"))
                    temp[index] = "drobiowe";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("indyk"))
                    temp[index] = "indyka";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("kość"))
                    temp[index] = "kością";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("domowy"))
                    temp[index] = "domowa";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("wieprzowy"))
                    temp[index] = "wieprzowa";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("twarz"))
                    temp[index] = "twarzy";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("ciało"))
                    temp[index] = "ciała";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("ręka"))
                    temp[index] = "rąk";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("czyszczenie"))
                    temp[index] = "czyszczenia";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("włos"))
                    temp[index] = "włosów";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("nić"))
                    temp[index] = "nici";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("dentystyczny"))
                    temp[index] = "dentystyczne";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("ciemny"))
                    temp[index] = "ciemnych";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("jasny"))
                    temp[index] = "jasnych";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("ząb"))
                    temp[index] = "zębów";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("mycie"))
                    temp[index] = "mycia";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("naczynia"))
                    temp[index] = "naczyń";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("podłoga"))
                    temp[index] = "podłóg";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("płukanie"))
                    temp[index] = "płukania";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("usta"))
                    temp[index] = "ust";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("pranie"))
                    temp[index] = "prania";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("ręcznik"))
                    temp[index] = "ręczniki";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("papierowy"))
                    temp[index] = "papierowe";
                
                else if (stem(s,kwestia.substring(0, prev))[0].equals("toaleta"))
                    temp[index] = "toalet";
                else
                temp[index] = stem(s,kwestia.substring(0, prev))[0];
                index=index+1;
            }
            catch(ArrayIndexOutOfBoundsException e){
                temp[index]=kwestia.substring(0, prev);
                index=index+1;
            }
                kwestia=kwestia.substring(prev+1);
                
            if(kwestia.contains(" ")){
                prev=kwestia.indexOf(" ");
            }
            else
            {
                prev=kwestia.length()-1;
            }
        }
        return temp;
    }
    
     public static boolean sprawdź_działy(String temp, ArrayList<String> rozmowa, Graphics g, boolean zaprzeczenie, boolean nAkcji){
        Random rand = new Random();
        Date date = new Date();
        rand.setSeed(date.getTime());
        int n = rand.nextInt(3);
        if ((temp.contains("chemi") || temp.contains("Chemi")) &&!(temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("warzyw") || temp.contains("Warzyw") || temp.contains("mięs") || temp.contains("Mięs")))
        {
            if(zaprzeczenie==false) {
                                if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu chemia.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale chemia.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale chemia.---->");
                    break;
                default:
                    break;
            }
            for (int i=1; i<dane.chemiarozmiar; i++)
            {
                
                int temph = 490+(i%21)*10;
                int tempw;
                if(i>20)
                {
                    tempw = 750;
                }
                else
                {
                    tempw = 500;
                }
                nAkcji=true;
                g.drawString(dane.chemia[i][0], tempw, temph);
            }}
            else{zaprzeczenie=false;}
            return true;
        } else {

        if ((temp.contains("nabiał") || temp.contains("Nabiał")) &&!(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("warzyw") || temp.contains("Warzyw") || temp.contains("mięs") || temp.contains("Mięs")))
        {
            if(zaprzeczenie==false) {
                                if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu nabiał.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale nabiał.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale nabiał.---->");
                    break;
                default:
                    break;
            }
                for (int i=1; i<dane.nabiałrozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.nabiał[i][0], tempw, temph);
                     nAkcji=true;
                }}
            else{zaprzeczenie=false;}
                return true;
        } else {
        if ((temp.contains("owoc") || temp.contains("Owoc")) &&!(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("warzyw") || temp.contains("Warzyw") || temp.contains("mięs") || temp.contains("Mięs")))
        {   if(zaprzeczenie==false) {
                            if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu owoce.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale owoce.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale owoce.---->");
                    break;
                default:
                    break;
            }
                for (int i=1; i<dane.owocerozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                    g.drawString(dane.owoce[i][0], tempw, temph);
                nAkcji=true;
                }}
            else{zaprzeczenie=false;}
                return true;
        } else {
        if ((temp.contains("pieczyw") || temp.contains("Pieczyw")) &&!(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("warzyw") || temp.contains("Warzyw") || temp.contains("mięs") || temp.contains("Mięs")))
        {   if(zaprzeczenie==false) {
                            if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu pieczywo.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale pieczywo.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale pieczywo.---->");
                    break;
                default:
                    break;
            }    
            for (int i=1; i<dane.pieczyworozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.pieczywo[i][0], tempw, temph);
                nAkcji=true;
                }}
            else{zaprzeczenie=false;}
            return true;
        } else {
        if ((temp.contains("warzyw") || temp.contains("Warzyw")) &&!(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("mięs") || temp.contains("Mięs")))
        {   if(zaprzeczenie==false) {
                            if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu warzywa.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale warzywa.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale warzywa.---->");
                    break;
                default:
                    break;
            }        
                for (int i=1; i<dane.warzywarozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>41)
                    {
                        tempw = 1000;
                    }
                    else if (i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.warzywa[i][0], tempw, temph);
                nAkcji=true;
                }}
            else{zaprzeczenie=false;}
                return true;
        } else {
        if ((temp.contains("mięs") || temp.contains("Mięs")) &&!(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("warzyw") || temp.contains("Warzyw")))
        {   if(zaprzeczenie==false) {
                            if(nAkcji==true){rozmowa.add(" ");}
            switch (n) {
                case 0:
                    rozmowa.add("Oto lista produktów z działu mięso.---->");
                    break;
                case 1:
                    rozmowa.add("Pokazuje liste produktów obecnie znajdujących się w dziale mięso.---->");
                    break;
                case 2:
                    rozmowa.add("Te oto produkty znajdują się w dziale mięso.---->");
                    break;
                default:
                    break;
            }        
                for (int i=1; i<dane.mięsorozmiar; i++)
                {
                    
                    int temph = 490+(i%21)*10;
                    int tempw = 0;
                    if(i>20)
                    {
                        tempw = 750;
                    }
                    else
                    {
                        tempw = 500;
                    }
                     g.drawString(dane.mięso[i][0], tempw, temph);
                nAkcji=true;
                }}
            else{zaprzeczenie=false;}
                return true;
        }
        else
            if(temp.contains("chemi") || temp.contains("Chemi") || temp.contains("nabiał") || temp.contains("Nabiał") || temp.contains("owoc") || temp.contains("Owoc") || temp.contains("pieczyw") || temp.contains("Pieczyw") || temp.contains("warzyw") || temp.contains("Warzyw") || temp.contains("mięs") || temp.contains("Mięs"))
              {
                                  if(nAkcji==true){rozmowa.add(" ");}
                rozmowa.add("Nie jestem wstanie pokazać Ci zawartości dwóch (lub więcej) działów jednocześnie");
                nAkcji=true;
                return true;
              }
              else
              return false;
     }
     }
     }
     }
     }
     }
     
    public static void analizuj (String temp, ArrayList<String> rozmowa, Graphics g, Move move)
    {
        ilość=1;
        Scenariusz1.zapytanko();
        String[] słowa = new String[100];
        słowa=Morf(temp); // Funkcja Morf zamienia (przy użyciu Morfologika) Stringa przechowującego
                          // to co wpisał użytkownik na tablice Stringów gdzie każdy wyraz lub  przecinek/kropka
                          // jest osobną pozycją w tablicy(odmienioną).
                          // tzn. że np. String "lubie placki, na wałbrzych" zamieni się na
                          // słowa[0]=="lubie"
                          // słowa[1]=="placek"
                          // słowa[2]==","
                          // słowa[3]=="na"
                          // słowa[4]=="wałbrzych"
                          // Oczywiście jeśli wszystko pójdzie zgodnie z planem bo Morfologik nie odmienia dobrze
                          // wszystkich słów i będziemy musieli się zająć obsługą wyrażeń których nie odmieni dobrze,
                          // sami.
                          
        
                          
                          
        temp=new String();
        for(String v: słowa)
        {
            if(v==null){break;}
            temp=temp+" "+v;
        }
        
        // TAKIE JAKBY FLAGI
        boolean usuwanie=false;
        boolean zaprzeczenie = false; // jeśli użytkownik wpisze nie ta zmienną zmienimy na false i nie wykonamy następnej akcji
                                     // zamiast cokolwiek robić zmienimy ją spowrotem na false. Tak samo jeśli znajdziemy przecinek
                                     // lub kropkę zmienimy ją na false.
        boolean ToNieJestPierwszaAkcja = false; // to jest konieczne gdyż ze względu na kolor tekstu program musi pisać
                                                // na zmiane z użytkownikiem więc po prostu KAŻDA AKCJA ZMIENIA TO NA TRUE
                                                // a jeśli przed akcją to true to musi dodać do rozmowy enter
        boolean ZapytanieOZawartośćDziału=false;
        boolean ZapytanieOZawartośćkoszyka=false;
        boolean ZapytanieOPodsumowanie=false;
        
        if((temp.contains("Tak") || temp.contains("tak") || temp.contains("TAK")) && czyza==1)
        {
            System.exit(0);
            
        }
          if((temp.contains("Nie") || temp.contains("nie") || temp.contains("NIE")) && czyza==1)
        {
            rozmowa.add("Więc kontynuujmy zakupy");
            ToNieJestPierwszaAkcja=true;
            
        }
          czyza=0;
        for(String v: słowa) // ta pentla służy właściwemu przetwarzaniu tekstu. Jeśli użytkownik wpisze
                             //"lubie placki, na wałbrzych" to w pierwszej iteracji v=="lubie" w drugiej v=="placki" (jak powyżej)
        {
            if(v==null){break;}
            String tempo= new String();
            tempo=v;
            if(usuwanie==false){
            
            
             System.out.print("\n"+tempo+"\n");

            if (tempo.equals("nie") || tempo.equals("Nie"))
            {
                zaprzeczenie=true;
                System.out.print("\n\nnie\n\n");
            }
            else
            if(tempo.contains("usu")  || tempo.contains("zlikwid") || tempo.contains("Wyrzu") || tempo.contains("Usu")  || tempo.contains("Zlikwid") || tempo.contains("wyrzu")){
                if(zaprzeczenie==false)
                {
                    usuwanie=true;
                    System.out.print("\n\nusuń\n\n");
                }
                else{
                    zaprzeczenie=false;
                }
            }else
            if (tempo.contains("chemi") || tempo.contains("Chemi") || tempo.contains("nabiał") || tempo.contains("Nabiał") || tempo.contains("owoc") || tempo.contains("Owoc") || tempo.contains("pieczyw") || tempo.contains("Pieczyw") || tempo.contains("warzyw") || tempo.contains("Warzyw") || tempo.contains("mięs") || tempo.contains("Mięs"))
            {
                if(zaprzeczenie==false)
                {
                ZapytanieOZawartośćDziału=true;
                }
                else
                {
                v="usunięto";
                zaprzeczenie=false;
                }
            }else
        if(tempo.contains("podsum")){
            if(zaprzeczenie==false){
                        ZapytanieOPodsumowanie=true;
            }
            else zaprzeczenie=false;}else        
        if(tempo.contains("kosz")){
            if(zaprzeczenie==false){
                        ZapytanieOZawartośćkoszyka=true;
            }
            else zaprzeczenie=false;}else
        if(tempo.equals("1") || tempo.equals("jeden")){ilość=1;}else
        if(tempo.equals("2") || tempo.equals("dwa")){ilość=2;}else
        if(tempo.equals("3") || tempo.equals("trzy")){ilość=3;}else
        if(tempo.equals("4") || tempo.equals("cztery")){ilość=4;}else
        if(tempo.equals("5") || tempo.equals("pięć")){ilość=5;}else    
        if(tempo.equals("6") || tempo.equals("sześć")){ilość=6;}else
        if(tempo.equals("7") || tempo.equals("siedem")){ilość=7;}else
        if(tempo.equals("8") || tempo.equals("osiem")){ilość=8;}else
        if(tempo.equals("9") || tempo.equals("dziewięć")){ilość=9;}else
        if(tempo.contains(".") || tempo.contains(",") || tempo.contains("!") || tempo.contains("?")){ilość=1; zaprzeczenie=false; usuwanie=false; ZapytanieOZawartośćDziału=false; ZapytanieOZawartośćkoszyka=false; ZapytanieOPodsumowanie=false;}else
        if(ST(dane.chemia, dane.chemiarozmiar, tempo, 3, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.nabiał, dane.nabiałrozmiar, tempo, 6, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.owoce, dane.owocerozmiar, tempo, 1, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.warzywa, dane.warzywarozmiar, tempo, 2, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.mięso, dane.mięsorozmiar, tempo, 4, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else
        if(ST(dane.pieczywo, dane.pieczyworozmiar, tempo, 5, rozmowa,g, zaprzeczenie, ToNieJestPierwszaAkcja,move)==1){ToNieJestPierwszaAkcja = true;}else{
            
             boolean wielowyrazowe=false;
             for(int i=0; i<Scenariusz1.j; i++){
              if(Scenariusz1.tab[i].split(" ")[0].equals(tempo)){

                    if(temp.contains(Scenariusz1.tab[i]))
                    {
                        szukanie100000(Scenariusz1.tab[i],rozmowa, g, zaprzeczenie, ToNieJestPierwszaAkcja, move);
                        ToNieJestPierwszaAkcja=true;
                        wielowyrazowe=true;
                        break;
                    }
                }
             }
             if(wielowyrazowe==false)
             for(int i=0; i<Scenariusz1.j; i++){

                if(Scenariusz1.tab[i].split(" ")[0].equals(tempo)){
                    rozmowa.add("W naszym magazynie znajduję się więcej niż jeden produkt o podanej nazwie."
                          + " Oto lista:");
                    int l=0;
                    for (int k=0; k<Scenariusz1.j; k++){
                        if(Scenariusz1.tab[k].split(" ")[0].equals(tempo)){
                        int temph = 490+(l%21)*10;
                        int tempw;
                        int lista=1;
                        if(l>20)
                            {
                            tempw = 1050;
                            }
                        else
                            {
                            tempw = 800;
                            }
                        l++;
                        g.drawString(Scenariusz1.tab[k], tempw, temph); 
                        }
                    }i=10000;     
                    ToNieJestPierwszaAkcja=true;
                } 
            }       
        }
            
        //TUTAJ
        
        }else{
                if(koszyk.Finddelete_Item(tempo, rozmowa)==1){if(ToNieJestPierwszaAkcja==true)rozmowa.add("");else ToNieJestPierwszaAkcja=true; usuwanie=false;}
            }
            if(tempo.contains("Zakończ") || tempo.contains("zakończ") || tempo.contains("Zakoncz") || tempo.contains("zakoncz") ){
            rozmowa.add("Czy na pewno chcesz zakończyć zakupy? Tak/Nie");
            ToNieJestPierwszaAkcja=true;

                koszyk.Podsumowanie_Koszyk(g, ToNieJestPierwszaAkcja, rozmowa);
            czyza=1;
        }
            
        }
        int licz=0;
        if(usuwanie==true){licz++;}
        if(ZapytanieOPodsumowanie==true){licz++;}
        if(ZapytanieOZawartośćkoszyka==true){licz++;}
        if(ZapytanieOZawartośćDziału==true){licz++;}
        
        if(licz==1){
        if(usuwanie==true)
            {
                rozmowa.add("Nie zrozumiałem co mam usunąć");
                if(ToNieJestPierwszaAkcja==true){
                    rozmowa.add("");
                }else
                ToNieJestPierwszaAkcja=true;
            }
        if(ZapytanieOPodsumowanie==true)
            {
                rozmowa.add("Pokazuje podsumowanie zakupów: ");
                koszyk.Podsumowanie_Koszyk(g, ToNieJestPierwszaAkcja, rozmowa);
                if(ToNieJestPierwszaAkcja==true)
                rozmowa.add("");
                else
                ToNieJestPierwszaAkcja=true;
            }
        if(ZapytanieOZawartośćkoszyka==true)
            {
                koszyk.Show_Koszyk(g, ToNieJestPierwszaAkcja, rozmowa);
                ToNieJestPierwszaAkcja=true;
            }
        if(ZapytanieOZawartośćDziału==true)
            {
                sprawdź_działy(temp, rozmowa,  g, zaprzeczenie, ToNieJestPierwszaAkcja);
                ToNieJestPierwszaAkcja=true;
            }
        }else if(licz>1){
                rozmowa.add("Nie potrafie wyświetlić tylu rzeczy naraz.");
                if(ToNieJestPierwszaAkcja==true){
                    rozmowa.add("");
                }else
                ToNieJestPierwszaAkcja=true;
        }
        
        
        
        if(ToNieJestPierwszaAkcja==false)
            {
                nierozumiem(rozmowa);
            }
        }

}