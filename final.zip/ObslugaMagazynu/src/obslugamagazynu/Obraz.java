
package obslugamagazynu;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;




public class Obraz extends Canvas {

    Image zdjecie;
     String sciezka;
    
    public void obraz(Graphics g, double dzial, int numer, int x , int y ,int rozx, int rozy){
        if(dzial==1){
            sciezka= "owoce//";
        }
        else if(dzial==2){
            sciezka="warzywa//";
        }
        else if(dzial==3 ){
            sciezka="chemia//";
        }
        else if(dzial==4){
            sciezka="mięso//";
        }
        else if(dzial==5){
            sciezka="pieczywo//";
        }
        else if(dzial==6){
            sciezka="nabiał//";
        }
        else{sciezka="";}
        
    if(numer!=0){
                 
            try{
         
                URL imagePath=Obraz.class.getResource(sciezka+numer+".jpg");
                this.zdjecie=Toolkit.getDefaultToolkit().getImage(imagePath);
            }
            catch(Exception e){
                e.printStackTrace();
            }
                   g.drawImage(zdjecie, x, y, rozx, rozy, this);

        }
    }
}





