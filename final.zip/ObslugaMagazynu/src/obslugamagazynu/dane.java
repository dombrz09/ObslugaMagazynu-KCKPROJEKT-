package obslugamagazynu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class dane {
	
	static String[][] chemia;
	static String[][] nabiał;
	static String[][] mięso;
	static String[][] owoce;
	static String[][] pieczywo;
	static String[][] warzywa;
        
        static int chemiarozmiar;
        static int nabiałrozmiar;
	static int mięsorozmiar;
        static int owocerozmiar;
        static int pieczyworozmiar;
        static int warzywarozmiar;
                
	static void Create_Arrays()
	{
		chemiarozmiar=35;
		chemia = new String[chemiarozmiar][6];
                nabiałrozmiar=30;
		nabiał = new String[nabiałrozmiar][6];
                mięsorozmiar=26;
		mięso = new String[mięsorozmiar][6];
                owocerozmiar=45;
		owoce = new String[owocerozmiar][6];
                pieczyworozmiar=18;
		pieczywo = new String[pieczyworozmiar][6];
                warzywarozmiar=51;
		warzywa = new String[warzywarozmiar][6];
		
		Scanner scanIn = null;
		int Rowc = 0;
		String InputLine = "";
		
		String chemiafileLocation;
		String nabiałfileLocation;
		String mięsofileLocation;
		String owocefileLocation;
		String pieczywofileLocation;
		String warzywafileLocation;
		
		chemiafileLocation = "\\src\\obslugamagazynu\\chemia.csv";
		nabiałfileLocation = "\\src\\obslugamagazynu\\nabiał.csv";
		mięsofileLocation = "\\src\\obslugamagazynu\\mięso.csv";
		owocefileLocation = "\\src\\obslugamagazynu\\owoce.csv";
		pieczywofileLocation = "\\src\\obslugamagazynu\\pieczywo.csv";
		warzywafileLocation = "\\src\\obslugamagazynu\\warzywa.csv";
		
		//Tutaj pobieramy ścieżkę do naszego projektu, a nastêpnie ³¹czymy go ze œcie¿k¹ do konkretnego pliku CSV.
		String dana=chemiafileLocation;
		String filePath = new File("").getAbsolutePath();
		filePath = filePath.concat(dana);
		System.out.println(filePath);
		
		try
		{
			for(int z=0; z<6; z++)
			{
				if(z==1) 
					{
						dana=nabiałfileLocation;
						filePath = new File("").getAbsolutePath();
						filePath = filePath.concat(dana);
					}
				if(z==2) 
					{
						dana=mięsofileLocation;
						filePath = new File("").getAbsolutePath();
						filePath = filePath.concat(dana);
					}
				if(z==3) 
					{
						dana=owocefileLocation;
						filePath = new File("").getAbsolutePath();
						filePath = filePath.concat(dana);
					}
				if(z==4) 
					{
						dana=pieczywofileLocation;
						filePath = new File("").getAbsolutePath();
						filePath = filePath.concat(dana);
					}
				if(z==5)
					{
						dana=warzywafileLocation;
						filePath = new File("").getAbsolutePath();
						filePath = filePath.concat(dana);
					}
				
				scanIn = new Scanner(new BufferedReader(new FileReader(filePath)));
				Rowc=0;
				while (scanIn.hasNextLine())
				{
					InputLine = scanIn.nextLine();
					
					String[] InArray = InputLine.split(";");
					
					
					for (int x = 0; x < InArray.length; x++)
					{
						if(z==0) chemia[Rowc][x] = (InArray[x]);
						else if(z==1) nabiał[Rowc][x] = (InArray[x]);
						else if(z==2) mięso[Rowc][x] = (InArray[x]);
						else if(z==3) owoce[Rowc][x] = (InArray[x]);
						else if(z==4) pieczywo[Rowc][x] = (InArray[x]);
						else if(z==5) warzywa[Rowc][x] = (InArray[x]);
					}
					
					Rowc++;
					
				}

			}
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}